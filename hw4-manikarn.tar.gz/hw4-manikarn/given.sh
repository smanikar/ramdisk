#!/bin/bash
while true
do
./osprdaccess -r -l -d 4 &

sleep 2
done &
