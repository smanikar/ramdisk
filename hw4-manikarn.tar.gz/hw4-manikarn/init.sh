#!/bin/bash
./osprdaccess -w -z
echo foobar | ./osprdaccess -w 
./osprdaccess -r 
echo ***Initialized***

